var XUI_AJAX_TEXT = 'Ajax跨域GET之测试样本';
